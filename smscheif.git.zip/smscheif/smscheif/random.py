import random

value = random.randint(1, 10000)
print(value)
